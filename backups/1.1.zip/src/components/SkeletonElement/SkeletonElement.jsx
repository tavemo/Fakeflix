import "./skeletonElement.scss"

const SkeletonElement = ({ type }) => <div className={`Skeleton ${type}`} />

export default SkeletonElement